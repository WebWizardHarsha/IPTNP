<?php
include("../middleware/auth_check.php");
include("../config/db.php");
if ($_SESSION['role'] !== 'admin') {
  header("Location: ../dashboard/index.php");
  exit;
}
$companies = mysqli_query($conn,"SELECT * FROM companies");
?>

<!DOCTYPE html>
<html>
<head>
  <title>Add Interview Round | IPTNP</title>
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<header class="nav">
  <div class="wrap nav-inner">
    <div class="logo">IPTNP ADMIN</div>
    <a href="index.php" class="btn">Back</a>
  </div>
</header>

<section class="section light">
  <div class="wrap">

    <h2>Add Interview Round</h2>

    <div class="form-box">
      <form method="post" action="add_round_action.php">

        <label>Select Company</label>
        <select name="company_id" required>
          <?php while($c=mysqli_fetch_assoc($companies)){ ?>
            <option value="<?= $c['company_id'] ?>"><?= $c['company_name'] ?></option>
          <?php } ?>
        </select>

        <label>Round Type</label>
        <input type="text" name="round_type" placeholder="Aptitude / Technical / HR" required>

        <button class="btn primary full">Add Round</button>
      </form>
    </div>

  </div>
</section>

</body>
</html>
