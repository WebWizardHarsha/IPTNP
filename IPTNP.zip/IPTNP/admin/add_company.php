<?php
include("../middleware/auth_check.php");
if ($_SESSION['role'] !== 'admin') {
  header("Location: ../dashboard/index.php");
  exit;
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Add Company | IPTNP</title>
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<header class="nav">
  <div class="wrap nav-inner">
    <div class="logo">IPTNP ADMIN</div>
    <a href="index.php" class="btn">Back</a>
  </div>
</header>

<section class="section light">
  <div class="wrap">

    <h2>Add Company</h2>

    <div class="form-box">
      <form method="post" action="add_company_action.php">

        <label>Company Name</label>
        <input type="text" name="company_name" required>

        <label>Company Description</label>
        <textarea name="description" rows="4" required></textarea>

        <button class="btn primary full">Add Company</button>
      </form>
    </div>

  </div>
</section>

</body>
</html>
