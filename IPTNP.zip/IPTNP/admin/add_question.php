<?php
include("../middleware/auth_check.php");
include("../config/db.php");
if ($_SESSION['role'] !== 'admin') {
  header("Location: ../dashboard/index.php");
  exit;
}
$rounds = mysqli_query($conn,"
SELECT r.round_id, r.round_type, c.company_name
FROM interview_rounds r
JOIN companies c ON r.company_id=c.company_id
");
?>

<!DOCTYPE html>
<html>
<head>
  <title>Add Question | IPTNP</title>
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<header class="nav">
  <div class="wrap nav-inner">
    <div class="logo">IPTNP ADMIN</div>
    <a href="index.php" class="btn">Back</a>
  </div>
</header>

<section class="section light">
  <div class="wrap">

    <h2>Add Interview Question</h2>

    <div class="form-box">
      <form method="post" action="add_question_action.php">

        <label>Select Round</label>
        <select name="round_id" required>
          <?php while($r=mysqli_fetch_assoc($rounds)){ ?>
            <option value="<?= $r['round_id'] ?>">
              <?= $r['company_name']." - ".$r['round_type'] ?>
            </option>
          <?php } ?>
        </select>

        <label>Question</label>
        <textarea name="question" rows="4" required></textarea>

        <button class="btn primary full">Add Question</button>
      </form>
    </div>

  </div>
</section>

</body>
</html>
