<?php
include("../middleware/auth_check.php");
if ($_SESSION['role'] !== 'admin') {
  header("Location: ../dashboard/index.php");
  exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard | IPTNP</title>
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<!-- TOP BAR -->
<header class="nav">
  <div class="wrap nav-inner">
    <div class="logo">IPTNP ADMIN</div>
    <div class="nav-links">
      <a href="../dashboard/index.php">User View</a>
      <a href="../auth/logout.php" class="btn">Logout</a>
    </div>
  </div>
</header>

<!-- ADMIN DASHBOARD -->
<section class="section light">
  <div class="wrap">

    <h2>Admin Dashboard</h2>

    <!-- STATS -->
    <div class="admin-stats">

      <div class="stat-card">
        <h3>Total Users</h3>
        <p>1</p>
      </div>

      <div class="stat-card">
        <h3>Total Companies</h3>
        <p>1</p>
      </div>

      <div class="stat-card">
        <h3>Shortlisted Applications</h3>
        <p>0</p>
      </div>

    </div>

    <!-- ACTIONS -->
    <h3 class="admin-sub">Admin Actions</h3>

    <div class="admin-actions">

      <a href="add_company.php" class="admin-card">
        Add Company
      </a>

      <a href="add_round.php" class="admin-card">
        Add Interview Rounds
      </a>

      <a href="add_question.php" class="admin-card">
        Add Interview Questions
      </a>

      <a href="view_users.php" class="admin-card">
        View Users
      </a>

    </div>

  </div>
</
