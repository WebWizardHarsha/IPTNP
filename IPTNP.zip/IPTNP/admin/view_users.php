<?php
include("../middleware/auth_check.php");
include("../config/db.php");
if ($_SESSION['role'] !== 'admin') {
  header("Location: ../dashboard/index.php");
  exit;
}
$users = mysqli_query($conn,"SELECT name,email,role FROM users");
?>

<!DOCTYPE html>
<html>
<head>
  <title>View Users | IPTNP</title>
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<header class="nav">
  <div class="wrap nav-inner">
    <div class="logo">IPTNP ADMIN</div>
    <a href="index.php" class="btn">Back</a>
  </div>
</header>

<section class="section light">
  <div class="wrap">

    <h2>Registered Users</h2>

    <div class="table-box">
      <table>
        <tr>
          <th>Name</th>
          <th>Email</th>
          <th>Role</th>
        </tr>
        <?php while($u=mysqli_fetch_assoc($users)){ ?>
        <tr>
          <td><?= $u['name'] ?></td>
          <td><?= $u['email'] ?></td>
          <td><?= ucfirst($u['role']) ?></td>
        </tr>
        <?php } ?>
      </table>
    </div>

  </div>
</section>

</body>
</html>
