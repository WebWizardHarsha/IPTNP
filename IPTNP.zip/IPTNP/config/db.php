<?php
$conn = mysqli_connect("localhost","root","","IPTNP");
if(!$conn){
  die("Database connection failed");
}
