<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Register | IPTNP</title>
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<div class="auth-page">

  <div class="auth-card">
    <h2>Create Your Account</h2>
    <p class="auth-sub">
      Start your interview process training with IPTNP
    </p>

    <form method="post" action="auth/register_action.php">

      <label>Full Name</label>
      <input type="text" name="name" required placeholder="Enter your full name">

      <label>Email Address</label>
      <input type="email" name="email" required placeholder="Enter your email">

      <label>Password</label>
      <input type="password" name="password" required placeholder="Create a password">

      <button type="submit" class="btn primary full">Create Account</button>
    </form>

    <p class="auth-footer">
      Already have an account?
      <a href="login.php">Login</a>
    </p>
  </div>

</div>

</body>
</html>
