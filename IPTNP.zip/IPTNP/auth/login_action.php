<?php
session_start();
include("../config/db.php");

$email = $_POST['email'];
$password = $_POST['password'];

$q = mysqli_query($conn,"SELECT * FROM users WHERE email='$email'");
$user = mysqli_fetch_assoc($q);

if($user && password_verify($password,$user['password'])){
  $_SESSION['user_id'] = $user['user_id'];
  $_SESSION['name'] = $user['name'];
  $_SESSION['role'] = $user['role'];

  if($user['role']=='admin'){
    header("Location: ../admin/index.php");
  } else {
    header("Location: ../dashboard/index.php");
  }
}else{
  echo "Invalid login";
}
