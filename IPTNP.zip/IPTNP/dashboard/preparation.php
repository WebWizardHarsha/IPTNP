<?php
include("../middleware/auth_check.php");
include("../config/db.php");

$user_id = $_SESSION['user_id'];

$companies = mysqli_query($conn,"
SELECT DISTINCT c.company_name
FROM companies c
");
?>

<!DOCTYPE html>
<html>
<head>
  <title>Preparation | IPTNP</title>
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<header class="nav">
  <div class="wrap nav-inner">
    <div class="logo">IPTNP</div>
    <a href="index.php" class="btn">Back</a>
  </div>
</header>

<section class="section light">
  <div class="wrap">

    <h2>Preparation Materials</h2>
    <p class="sub-text">
      Practice company-wise interview questions
    </p>

    <?php
    if(mysqli_num_rows($companies)>0){
      while($c=mysqli_fetch_assoc($companies)){
        echo "<div class='prep-card'>";
        echo "<h3>".$c['company_name']."</h3>";

        $rounds = mysqli_query($conn,"
        SELECT round_type FROM interview_rounds r
        JOIN companies c ON r.company_id=c.company_id
        WHERE c.company_name='".$c['company_name']."'
        ");

        while($r=mysqli_fetch_assoc($rounds)){
          echo "<p>• ".$r['round_type']."</p>";
        }

        echo "</div>";
      }
    } else {
      echo "<p>No preparation data available.</p>";
    }
    ?>

  </div>
</section>

</body>
</html>
