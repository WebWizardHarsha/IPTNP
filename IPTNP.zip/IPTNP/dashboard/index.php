<?php
include("../middleware/auth_check.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>User Dashboard | IPTNP</title>
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<header class="nav">
  <div class="wrap nav-inner">
    <div class="logo">IPTNP</div>
    <div class="nav-links">
      <?php if($_SESSION['role']=='admin'){ ?>
        <a href="../admin/index.php">Admin Panel</a>
      <?php } ?>
      <a href="../auth/logout.php" class="btn">Logout</a>
    </div>
  </div>
</header>

<section class="section light">
  <div class="wrap">

    <h2>Welcome, <?php echo $_SESSION['name']; ?></h2>
    <p class="sub-text">
      Track your preparation and get ready for interviews.
    </p>

    <div class="dashboard-cards">

      <a href="preparation.php" class="dash-card">
        <h3>Preparation</h3>
        <p>Company-wise interview questions & progress</p>
      </a>

      <a href="shortlisted.php" class="dash-card">
        <h3>Shortlisted Companies</h3>
        <p>View companies where you are shortlisted</p>
      </a>

      <a href="#" class="dash-card disabled">
        <h3>AI Insights</h3>
        <p>Coming soon</p>
      </a>

    </div>

  </div>
</section>

</body>
</html>
