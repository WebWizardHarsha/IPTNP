<?php
include("../middleware/auth_check.php");
include("../config/db.php");

$user_id = $_SESSION['user_id'];

$q = mysqli_query($conn,"
SELECT c.company_name, ja.job_role
FROM job_applications ja
JOIN companies c ON ja.company_id=c.company_id
WHERE ja.candidate_id=$user_id
AND ja.status='Shortlisted'
");
?>

<!DOCTYPE html>
<html>
<head>
  <title>Shortlisted Companies | IPTNP</title>
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<header class="nav">
  <div class="wrap nav-inner">
    <div class="logo">IPTNP</div>
    <a href="index.php" class="btn">Back</a>
  </div>
</header>

<section class="section light">
  <div class="wrap">

    <h2>Your Shortlisted Companies</h2>

    <?php if(mysqli_num_rows($q)>0){
      while($r=mysqli_fetch_assoc($q)){ ?>
        <div class="prep-card">
          <h3><?php echo $r['company_name']; ?></h3>
          <p>Role: <?php echo $r['job_role']; ?></p>
        </div>
    <?php }} else { ?>
      <p>No shortlisted companies yet.</p>
    <?php } ?>

  </div>
</section>

</body>
</html>
