<?php
include("../middleware/auth_check.php");
include("../config/db.php");

echo "<p>Focus more on Technical questions for better performance.</p>";
