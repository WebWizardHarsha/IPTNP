<?php
include("../middleware/auth_check.php");
include("../config/db.php");

$q = mysqli_query($conn,"SELECT question FROM company_questions");
while($r=mysqli_fetch_assoc($q)){
  echo "<p>".$r['question']."</p>";
}
