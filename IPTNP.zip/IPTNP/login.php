<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login | IPTNP</title>
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<div class="auth-page">

  <div class="auth-card">
    <h2>Welcome Back</h2>
    <p class="auth-sub">
      Login to continue your interview training
    </p>

    <form method="post" action="auth/login_action.php">

      <label>Email Address</label>
      <input type="email" name="email" required placeholder="Enter your email">

      <label>Password</label>
      <input type="password" name="password" required placeholder="Enter your password">

      <button type="submit" class="btn primary full">Login</button>
    </form>

    <p class="auth-footer">
      New to IPTNP?
      <a href="register.php">Create an account</a>
    </p>
  </div>

</div>

</body>
</html>
