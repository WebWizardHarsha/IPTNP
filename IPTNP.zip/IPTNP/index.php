<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>IPTNP – Interview Process Training & Practice</title>
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<!-- NAVBAR -->
<header class="nav">
  <div class="wrap nav-inner">
    <div class="logo">IPTNP</div>
    <div class="nav-links">
      <a href="login.php">Login</a>
      <a href="register.php" class="btn primary">Sign Up</a>
    </div>
  </div>
</header>

<!-- HERO -->
<section class="hero">
  <div class="wrap hero-inner">
    <div class="hero-text">
      <h1>Empowering Careers,<br>Shaping Interview Success</h1>
      <p>
        IPTNP (Interview Process Training & Practice) helps students and freshers
        understand, train, and practice real interview processes followed by companies.
      </p>
      <div class="hero-actions">
        <a href="register.php" class="btn primary large">Get Started</a>
        <a href="login.php" class="btn secondary">Login</a>
      </div>
    </div>
  </div>
</section>

<!-- WHY CHOOSE -->
<section class="section light">
  <div class="wrap">
    <h2>Why Choose IPTNP?</h2>
    <div class="cards">
      <div class="card">Company-wise Interview Training</div>
      <div class="card">Round-based Preparation</div>
      <div class="card">Progress Tracking</div>
      <div class="card">Mock Interviews</div>
    </div>
  </div>
</section>

<!-- HOW IT WORKS -->
<section class="section">
  <div class="wrap">
    <h2>How It Works</h2>
    <ol class="steps">
      <li>Admin adds companies, interview rounds, and questions</li>
      <li>Users practice questions based on interview stages</li>
      <li>Track progress and revise using mock mode</li>
    </ol>
  </div>
</section>

<!-- CTA -->
<section class="cta">
  <div class="wrap center">
    <h2>Start Your Interview Preparation Today</h2>
    <p>Structured training. Focused practice. Real results.</p>
    <a href="register.php" class="btn primary large">Create Free Account</a>
  </div>
</section>

<!-- FOOTER -->
<footer class="footer">
  <div class="wrap center">
    © <?php echo date("Y"); ?> IPTNP – Interview Process Training & Practice
  </div>
</footer>

</body>
</html>
